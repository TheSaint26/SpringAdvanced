package bg.softuni.booksrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
