package bg.softuni.booksrestclient;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BooksRestClientApplication {

	public static void main(String[] args) {
		SpringApplication.run(BooksRestClientApplication.class, args);
	}

}
