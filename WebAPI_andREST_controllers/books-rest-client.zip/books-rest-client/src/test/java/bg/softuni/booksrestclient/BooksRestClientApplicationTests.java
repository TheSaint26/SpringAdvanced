package bg.softuni.booksrestclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BooksRestClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
